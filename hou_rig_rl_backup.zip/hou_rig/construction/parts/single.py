import hou
import master
import hou_rig.utils
import hou_rig.line_maker


class single(master.master):
    def __init__(self, node, rig_subnet):
        self.node = node
        self.rig_subnet = rig_subnet
        self.limb_subnet = self.create_rig_node(self.rig_subnet)

        self.node_rename(self.node, self.limb_subnet)
        self.make_color(self.node)
        self.colorize_node(self.limb_subnet, self.color)
        self.position_node(self.node, self.limb_subnet)

        self.create_spare_parms_folder()

        working_node_list = self.working_nodes_list(self.node)

        self.create_bones(self.node.parm("hook"), working_node_list, self.limb_subnet)
        self.colorize_the_object(self.created_bones, self.color)

        list_of_bones_to_promote = self.created_bones[0:-1]

        hou_rig.utils.list_of_parms_to_promote_to_ui(list_of_bones_to_promote,
             #[["t", "tuple", "jwnp"], ["r", "tuple", "jwnp"], ["scale", "parm", "jwnp"], ["length", "parm", "jwnp"]],
                                                     [["t", "tuple", "jwnp"], ["r", "tuple", "jwnp"],
                                                      ["scale", "parm", "jwnp"]], node_to_parm=self.rig_subnet,
                                                     into_this_folder=["Rig Parms", self.node.name(), "Bones"])
        self.create_ik()
        self.create_stretchy()
        self.ik_stretchy_knee_slide()

        self.toon_curve(self.node, self.chain_list[0:-1])

        self.destroy_last_bone()