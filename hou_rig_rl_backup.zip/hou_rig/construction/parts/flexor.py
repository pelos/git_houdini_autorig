import hou
import random
#todo different ways to generate the curve, points selected in the viewport, we can use the for eyebrows for example.
#todo promote parameters of the null_cvs
#todo create a parameter in ui to with a script to turn off and on null_cvs
#todo create a parameter in ui to with a script to turn off and on  the display of the bones, toon_curve_flexor
#todo create a parameter in ui to with a script to turn off and on  the display of the curve



class flexor(object):
    def __init__(self):
        pass

    def test(self):
        self.run_toon_curves(hou.node('/obj/guide_curve'), 6, "bone_for_test", where=hou.node("/obj/subnet1"))

    def prep_curve(self):
        pass
        #add all the node needed for bscale attrib in the vop sop.

    def run_toon_curves(self, curve, bone_num, parent, name_of_bones="chain_bone", where=None, name=None):
        """
        run the necessary functions to get bones following a curve.
        """
        curve_subnet = self.curve_bones_subnet(curve, where=where)

        self.list_chain = self.toon_bones_creating(curve, bone_num, "bone_chain_test", where=curve_subnet)
        fetcher = self.fetch_parent(curve_subnet, parent)
        self.list_chain[1].setInput(0, fetcher)

        ik_node = self.bones_follow_ik_curve(curve, self.list_chain[0], node_name=name_of_bones, where=curve_subnet)
        self.set_bones_ik_solver(self.list_chain[0], ik_node)
        self.set_bone_length_parm(self.list_chain[0], curve)
        wt = self.set_bone_deform_region(self.list_chain[0], curve, name=name_of_bones, where=curve_subnet)
        self.randomize_color_bone(self.list_chain[0])


    def curve_bones_subnet(self, curve, where=None, name=None):
        """
        create a subnet where the created nodes will be created
        @param curve: the curve that will be use
        @param where: if we want to put this subnet somewhere else.
        @return: the subnet
        """
        if where is None:
            where = curve.parent()

        if name is not None:
            curve_subnet = where.createNode("subnet", name)
        elif name is None:
            curve_subnet = where.createNode("subnet", curve.name()+"_flexor")

        return curve_subnet

    def fetch_parent(self, where, parent):
        fetch = where.createNode("fetch", "fetch_"+parent.name())
        fetch.parm("fetchobjpath").set(fetch.relativePathTo(parent))
        fetch.parm("useinputoffetched").set(1)
        fetch.parm("fetchsubnet").set(1)
        fetch.setDisplayFlag(0)
        return fetch


    def toon_bones_creating(self, curve, bone_num, name_of_bones="chain_bone", where=None):
        """
        generate a chain of
        curve: the curve that will be populated with bones
        int@bone_num: how many bones will be created.
        str@name_of_bones: names that the bones
        tuple@color: tuple of color,[0.2,0.5,0.35] colorize the created bone nodes.

        returns, the created list of bones, the ik_root
        """
        mp = curve.position()
        if where is None:
            where = curve.parent()

        ik_root = where.createNode("null", name_of_bones+"root")
        ik_root.setPosition([mp[0]+1, mp[1]-1])
        ik_root.setDisplayFlag(0)
        mp = [ik_root.position()[0], ik_root.position()[1]-1]

        #list_chain = [ik_root]
        list_chain = []

        for i in range(0, bone_num):
            bone = where.createNode("bone", name_of_bones+"_"+str(i))
            bone.setPosition([mp[0], mp[1]-i])
            list_chain.append(bone)
            if i == 0:
                bone.setInput(0, ik_root)
            else:
                bone.setInput(0, prev_bone)
            prev_bone = bone
        return list_chain, ik_root

    def bones_follow_ik_curve(self, curve, chain=[], root_bone=None, end_bone=None, node_name="ik_chopnet",
                              where=None):
        """
        where what level the creation will happen
        curve that will provide the path
        chain list of nodes(bones) to use
        name of the node
        """
        if where is None:
            where = curve.parent()

        chop = where.createNode("chopnet", node_name)
        chop.setPosition([curve.position()[0]-1.5, curve.position()[1]-1.5])
        ik = chop.createNode("inversekin", "inversekin_"+node_name)
        ik.parm("solvertype").set(4)
        ik.parm("curvepath").set(ik.relativePathTo(curve))
    #    ik.parm("curvepath").set(ik.relativePathTo(hou.node(curve.path()))) maybe have to be set like this.
        if root_bone is not None:
            ik.parm("bonerootpath").set(ik.relativePathTo(root_bone))
        else:
            for n in chain:
                if n.type().nameComponents()[2] == "bone":
                    ik.parm("bonerootpath").set(ik.relativePathTo(n))
                    break
                else:
                    continue

        if end_bone is None:
            end_bone = chain[-1]
        ik.parm("boneendpath").set(ik.relativePathTo(end_bone))

        return ik

    def set_bones_ik_solver(self, chain, solver_node):
        """
        put the ik_solver chop into the parameter of the bones
        """
        for i in chain:
            try:
                i.parm("solver").set(i.relativePathTo(solver_node))
            except:
                pass

    def set_bone_length_parm(self, chain, curve):
        """
        set the length of the bones to streactch acording the the curve.
        """
        amount_of_bones = len(chain)
        for i in chain:
            i.parm("length").setExpression('arclen("%s",0,0,1)/%s'%(i.relativePathTo(curve), amount_of_bones))

    def set_bone_deform_region(self, chain, curve, name=None, where=None):
        """
        creates a geometry that just brings the bones as point, to use as helper to get the
        bone position in world space
        where = what level inside houdini the object world transform helper will be created
        chain = list of bones that will get the parm
        name the name of the world transform helper

        returns wt geometry node.
        """
        if name is None:
            name = curve.name()

        if where is None:
            where = curve.parent()

        wt = where.createNode("geo", name+"_world_transform")
        wt.node("file1").destroy()
        wt.setPosition([curve.position()[0]-1.5, curve.position()[1]-1])
        wt.setDisplayFlag(0)
        merge_nodes=[]
        for i in chain:
            if i.type().nameComponents()[2]== "bone":
                merge = wt.createNode("object_merge", i.name())
                merge.parm("xformtype").set(1)
                merge.parm("objpath1").set(merge.relativePathTo(i))
                merge_nodes.append(i)

        for i, j in zip(chain, merge_nodes):
            rel_path = i.relativePathTo(curve)
            wt_rel_path = i.relativePathTo(j)

            i.parm("crscalex").setExpression('point("%s",nearpoint("%s", point("%s", 0, "P", 0), point("%s", 0, "P", 1), point("%s", 0, "P", 2) ), "bscale", 0)'%(rel_path, rel_path, wt_rel_path, wt_rel_path, wt_rel_path))
            i.parm("crscaley").setExpression('point("%s",nearpoint("%s", point("%s", 0, "P", 0), point("%s", 0, "P", 1), point("%s", 0, "P", 2) ), "bscale", 0)'%(rel_path, rel_path, wt_rel_path, wt_rel_path, wt_rel_path))

        wt.layoutChildren()
        return wt

    def randomize_color_bone(self, chain):
        """
        do to a chain of nodes will randomize the wireframe color
        """
        for i in chain:
            i.parm("dcolorr").set(random.random())
            i.parm("dcolorg").set(random.random())
            i.parm("dcolorb").set(random.random())