#todo CREATE DOG LEG that will contain 4 guide nulls
import master
import hou_rig.utils

class dog_leg(master.master):
	def __init__(self):
		print "this is a dog leg"