""" in houdini
from hou_rig.construction.builder import build_stuff
build_stuff()
"""
#todo make a variable list that acumulates the deformers, bones, or toony curves or nulls.
import hou
import hou_rig.utils
import hou_rig.construction.parts.geometry
#from hou_rig import utils

#from hou_rig.construction.parts import arm, leg, single, spine, flexor, null, character_placer


class build_stuff():
    """
    loop all the classes and construct the rig part base on that.
    """

    def __init__(self):
        #order them  that the character placer is the first one.

        list_of_node_to_build = hou.selectedNodes()
        if len(list_of_node_to_build) == 1 and "pre_rig" in list_of_node_to_build[0].name():
            list_of_node_to_build[0].extractAndDelete()
            list_of_node_to_build = hou.selectedNodes()

        #converting the selected node tuple into a list
        list_of_node_to_build = list(list_of_node_to_build)

        #extracting character_placer

        for index, i in enumerate(list_of_node_to_build):
            if i.parm("type").eval() == "character_placer":
                ch_placer = list_of_node_to_build.pop(index)
        #putting it at the front of the list
        list_of_node_to_build.insert(0, ch_placer)
        #putting it at the back of the list
        #list_of_node_to_build.append(ch_placer)

        lvl = ch_placer.parent()
        name = ch_placer.parm("name").eval()

        """
        for index, i in enumerate(list_of_node_to_build):
            for j in i.parms():
                if j.name() == "name":
                    #means this is character_placer
                    lvl = i.parent()
                    name = j.eval()
                    #we take out the character placer form the list
                    ch_placer = list_of_node_to_build.pop(index)
        # we added back to the list at the end.
        list_of_node_to_build.append(ch_placer)
        #list_of_node_to_build.insert(1,ch_placer)
        """

        pre_rig = list_of_node_to_build[0].parent().collapseIntoSubnet(list_of_node_to_build, "pre_rig_"+name)
        pre_rig.setDisplayFlag(0)
        pre_rig.setSelectableInViewport(0)
        list_of_node_to_build = pre_rig.children()


        #todo dowe create the rig subnet in this module or in the init of each class? is we do in each class is more independent
        # create the Master subnet where all the rig parts will be created
        rig_subnet = lvl.createNode("subnet", name)
        pre_rig_position = pre_rig.position()
        rig_subnet.setPosition([pre_rig_position[0], pre_rig_position[1]-1])
        #hidden the subnet folder

        hou_rig.utils.ui_folder(rig_subnet, in_this_folder=["Rig Parms"], insert_before_parm=(0,))
        hou_rig.utils.hide_folder_or_parm_from_ui(rig_subnet, hide_this=["Subnet"])
        hou_rig.utils.hide_folder_or_parm_from_ui(rig_subnet, hide_this=["Transform"])




# Check each node and import the proper class .py file and run it.
        for index, i in enumerate(list_of_node_to_build):
            rig_type = i.parm("type").eval()

            var = __import__("hou_rig.construction.parts."+rig_type, globals(), locals(), ["*"], -1)
            g = getattr(var, rig_type)
            class_type = g(i, rig_subnet)
