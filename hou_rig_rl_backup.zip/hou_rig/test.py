import hou
import utils


def bone_shape(parent):
    bone_subnet = parent.createNode("subnet", "subnet_bone_shape")
    tube_node = bone_subnet.createNode("tube")
    tube_node.parm("type").set(1)
    tube_node.parm("orient").set(1)
    tube_node.parm("rows").set(2)
    tube_node.parm("cols").set(4)
    tube_node.parm("cap").set(1)
    tube_node.parm("ty").setExpression('ch("height")*.5')

    utils.promote_parm_to_ui(tube_node.parm("rad1"), bone_subnet, parm_name="rad1")
    utils.promote_parm_to_ui(tube_node.parm("rad2"), bone_subnet, parm_name="rad2")
    utils.promote_parm_to_ui(tube_node.parm("height"), bone_subnet, parm_name="height")
    #utils.hide_folder_or_parm_from_ui(bone_subnet, hide_this="label1")

    xf = bone_subnet.createNode("xform")
    xf.parm("ry").set(-45)
    xf.setInput(0, tube_node)

    fuse_node = bone_subnet.createNode("fuse")
    fuse_node.setInput(0, xf)

    pb_node = bone_subnet.createNode("polybevel")
    pb_node.parm("beveltype").set(3)
    pb_node.parm("relinset").set(0.145)
    pb_node.setInput(0, fuse_node)

    gr_node = bone_subnet.createNode("group")
    gr_node.parm("crname").set("fins")
    gr_node.parm("pattern").set("2-5")
    gr_node.setInput(0, pb_node)

    pe_node = bone_subnet.createNode("polyextrude")
    pe_node.parm("group").set("fins")
    pe_node.parm("inset").set("-0.015")
    pe_node.parm("ltz").set("0.025")
    pe_node.setInput(0, gr_node)
    #----------------------------------------
    t_node = bone_subnet.createNode("tube")
    t_node.parm("type").set(1)
    t_node.parm("orient").set(1)
    t_node.parm("rows").set(4)
    t_node.parm("cols").set(6)
    t_node.parm("cap").set(1)
    t_node.parm("ty").setExpression('ch("height")*.5')

    utils.promote_parm_to_ui(t_node.parm("rad1"), bone_subnet, parm_name="t_rad1")
    utils.promote_parm_to_ui(t_node.parm("rad2"), bone_subnet, parm_name= "t_rad2")
    utils.promote_parm_to_ui(t_node.parm("height"), bone_subnet, parm_name= "t_height")

    f_node = bone_subnet.createNode("fuse")
    f_node.setInput(0, t_node)

    edit_node = bone_subnet.createNode("edit", "edit_the_shape_to_match_the_geometry_to_your_liking")
    edit_node.setInput(0, f_node)
    #-------------------------------------------

    sw_node = bone_subnet.createNode("switch")
    sw_node.setNextInput(pe_node)
    sw_node.setNextInput(edit_node)

    color_node = bone_subnet.createNode("color", "color_from_bone")
    color_node.setInput(0, sw_node)

    null_out = bone_subnet.createNode("null", "Out")
    null_out.setColor(hou.Color((0.2,0.3,0.5)))
    null_out.setInput(0,color_node)

    bone_subnet.layoutChildren()