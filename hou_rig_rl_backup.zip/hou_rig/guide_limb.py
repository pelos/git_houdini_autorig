#todo: sure the scaling of the my_null is correct to the orientation of the bones
#todo make a nice arrow pointing the direction and maybe orientation? of the my_null
#todo: my_null use null  instead geo and start from scratch

#todo make a procedural model inside a subnet to represent the bone
#that way they can select it easily in the viewport
#and then we can copy paste that node into the autorig limb and use that to display instead the bone
#maybe that subnet can be inside the guide null, like max bones that can have volume
#a line that point to another line and then sweep a shape
#a line and then a sweep a square and then extrude lime max
#and then copy paste that subnet into the bone.

#todo: MOVE THE CHARACTER PLACER function inside the class, consistency
#todo make sure the character placer is the first one, looks like now is using creation order instead list order.

import hou
import hou_rig.line_maker
import hou_rig.my_null
import hou_rig.utils



""" in houdini
from hou_rig import guide_limb
guide_limb.character_placer()
"""
def character_placer():
    subnet = hou.node("/obj").createNode("subnet", "character_placer")
    subnet.setColor(hou.Color((.3, .3, .3)))
    #subnet.setSelectableInViewport(0)
    tg = subnet.parmTemplateGroup()
    folder = hou.FolderParmTemplate("folder", "Rig Parms")
    name_parm = hou.StringParmTemplate("name", "Name", 1, help="character rig to build", default_value=["Bided", ])

    c_center = hou.FloatParmTemplate("color_center", "Color Center", 3, default_value=([.75, .75, .75]), min=0, max=1,
                                     min_is_strict=False, max_is_strict=False, look=hou.parmLook.ColorSquare,
                                     naming_scheme=hou.parmNamingScheme.RGBA)

    c_right = hou.FloatParmTemplate("color_right", "Color Right", 3, default_value=([0, 0, 1]), min=0, max=1,
                                    min_is_strict=False, max_is_strict=False, look=hou.parmLook.ColorSquare,
                                    naming_scheme=hou.parmNamingScheme.RGBA)

    c_left = hou.FloatParmTemplate("color_left", "Color Left", 3, default_value=([1, 0, 0]), min=0, max=1,
                                   min_is_strict=False, max_is_strict=False, look=hou.parmLook.ColorSquare,
                                   naming_scheme=hou.parmNamingScheme.RGBA)
    rig_type = hou.StringParmTemplate("type", "type", 1, default_value=["character_placer"])

    hou_parm_template2 = hou.StringParmTemplate("position", "Position", 1, default_value=(["center"]),
                                                naming_scheme=hou.parmNamingScheme.Base1,
                                                string_type=hou.stringParmType.Regular,
                                                menu_items=([""]),
                                                menu_labels=([""]),
                                                icon_names=([]),
                                                item_generator_script="",
                                                item_generator_script_language=hou.scriptLanguage.Python,
                                                menu_type=hou.menuType.Normal)
    hou_parm_template2.hide(1)


    folder.addParmTemplate(name_parm)
    folder.addParmTemplate(c_center)
    folder.addParmTemplate(c_right)
    folder.addParmTemplate(c_left)
    folder.addParmTemplate(rig_type)
    folder.addParmTemplate(hou_parm_template2)

    tg.insertBefore((0,), folder)
    subnet.setParmTemplateGroup(tg)
    subnet.parm("type").lock(1)

    #ch_placer = subnet.createNode("null", "character_placer")
    #ch_placer.setDisplayFlag(0)
    #hook = subnet.createNode("null", "character_placer_hook")
    hook = subnet.createNode("null", "chain_1")
    #hook = subnet.createNode("null", "character_placer")
    #hook.setInput(0,ch_placer,0)
    hook.parm("controltype").set(1)
    hook.parm("orientation").set(2)
    #hook.setSelectableInViewport(0)

    subnet.layoutChildren()

"""
#in houdini shelf button put this code for each limb type
from hou_rig import guide_limb
if len(hou.selectedNodes()) == 0 or hou.selectedNodes()[0].type().nameComponents()[2 ]== "subnet":
    hou.ui.displayMessage("Make sure you are selecting a valid Hook")
else:
    limb = guide_limb.limb(hook = hou.selectedNodes()[0], limb_type = "single")
    limb.single()
"""


class limb():
    def __init__(self, hook="../find_hook", limb_type="single"):
        self.limb_type = limb_type
        self.hook = hook

        self.g_node = hou.node("/obj").createNode("subnet", "guide_" + self.limb_type)

    def put_ui_in_node(self, node_to_put_ui,
                    default_type="single",
                    kinematic_parm=True,
                    kinematics_labels = ["No Kinematics", "IK", "IK_With Effector"],
                    stretchy_parm=True,
                    ik_slide_parm =True,
                    curve_toon_parm=True,
                    division_parm=True,
                    ik_goal_label_warning=True,
                    ik_goals_parm=True,
                    ik_twist_parm=True,
                    position_parm=True):

        template_group = node_to_put_ui.parmTemplateGroup()

        # Code for parameter template Make  RIG_PARMS FOLDER
        hou_parm_template = hou.FolderParmTemplate("folder", "Rig Parms", folder_type=hou.folderType.Tabs, default_value=0, ends_tab_group=False)
        hou_parm_template.setTags({"visibletabs": "111"})

        # Code for parameter template HOOK
        hou_parm_template2 = hou.StringParmTemplate("hook", "Hook", 1, default_value=(["parent"]),
                                                    naming_scheme=hou.parmNamingScheme.Base1,
                                                    string_type=hou.stringParmType.NodeReference,
                                                    menu_items=([]),
                                                    menu_labels=([]),
                                                    icon_names=([]),
                                                    item_generator_script="",
                                                    item_generator_script_language=hou.scriptLanguage.Python,
                                                    menu_type=hou.menuType.Normal)
        hou_parm_template2.setTags({"oprelative": "."})
        hou_parm_template.addParmTemplate(hou_parm_template2)

        # Code for parameter template TYPE OF CLASS!!!
        hou_parm_template2 = hou.StringParmTemplate("type", "type", 1, default_value=([default_type]),
                                                    naming_scheme=hou.parmNamingScheme.Base1,
                                                    string_type=hou.stringParmType.Regular,
                                                    menu_items=(["single","spine","leg","arm","foot","dog_leg",
                                                                 "null", "flexor"]),
                                                    menu_labels=(["single","spine","leg","arm","foot","dog_leg",
                                                                  "null", "flexor"]),
                                                    icon_names=([]), item_generator_script="",
                                                    item_generator_script_language=hou.scriptLanguage.Python,
                                                    menu_type=hou.menuType.Normal)
        hou_parm_template2.setJoinWithNext(1)
        hou_parm_template.addParmTemplate(hou_parm_template2)

        if position_parm is True:
            hou_parm_template2 = hou.StringParmTemplate("position", "Position", 1, default_value=(["left"]),
                                                       naming_scheme=hou.parmNamingScheme.Base1,
                                                       string_type=hou.stringParmType.Regular,
                                                       menu_items=(["left", "center", "right"]),
                                                       menu_labels=(["left", "center", "right"]),
                                                       icon_names=([]),
                                                       item_generator_script="",
                                                       item_generator_script_language=hou.scriptLanguage.Python,
                                                       menu_type=hou.menuType.Normal)
            hou_parm_template.addParmTemplate(hou_parm_template2)

        # Code for parameter template KINEMATIC TYPE
        if kinematic_parm is True:
            menu_items_names = range(0, len(kinematics_labels))
            menu_items_names = map(str, menu_items_names)
            hou_parm_template2 = hou.MenuParmTemplate("k_type", "Kinematic Type",
                                                      menu_items=menu_items_names,
                                                      menu_labels=kinematics_labels,
                                                      default_value=0, icon_names=([]), item_generator_script="",
                                                      item_generator_script_language=hou.scriptLanguage.Python,
                                                      menu_type=hou.menuType.Normal)

            hou_parm_template2.setJoinWithNext(True)
            hou_parm_template.addParmTemplate(hou_parm_template2)

        # Code for parameter template STRETCHY TOGGLE
        if stretchy_parm is True:
            hou_parm_template2 = hou.ToggleParmTemplate("stretchy", "stretchy", default_value=True)
            hou_parm_template2.setConditional( hou.parmCondType.DisableWhen, "{ k_type == 0 }")
            hou_parm_template2.setJoinWithNext(True)
            hou_parm_template.addParmTemplate(hou_parm_template2)

        # Code for parameter template IK SLIDE
        if ik_slide_parm is True:
            hou_parm_template2 = hou.ToggleParmTemplate("ik_slide", "IK_slide", default_value=True)
            hou_parm_template2.setConditional( hou.parmCondType.DisableWhen, "{ k_type == 0 }")
            hou_parm_template2.setJoinWithNext(True)
            hou_parm_template.addParmTemplate(hou_parm_template2)


        # Code for parameter template TOON CURVE to put a curve along that drive  a chain of bones
        if curve_toon_parm is True:
            hou_parm_template2 = hou.ToggleParmTemplate("toon_curve", "toon_curve", default_value=True)
            hou_parm_template2.setConditional( hou.parmCondType.DisableWhen, "{ k_type == 0 }")
            hou_parm_template2.setJoinWithNext(True)
            hou_parm_template.addParmTemplate(hou_parm_template2)

        # Code for parameter template how many bones on the curve
        if division_parm is True:
            hou_parm_template2 = hou.IntParmTemplate("divisions", "Divisions", 1, default_value=([8]),
                                                     min=0, max=10,
                                                     min_is_strict=False, max_is_strict=False,
                                                     naming_scheme=hou.parmNamingScheme.Base1)
            hou_parm_template.addParmTemplate(hou_parm_template2)

        # Code for parameter template just a label warning the user to use relative paths.
        if ik_goal_label_warning is True:
            hou_parm_template2 = hou.LabelParmTemplate("ik_warning", "ik_warning",
                                                    column_labels=(["IK Constraints must be in relative path."]))
            hou_parm_template2.hideLabel(True)
            hou_parm_template.addParmTemplate(hou_parm_template2)

        # Code for parameter template  THE IK GOAL PARENTS BLENDS
        if ik_goals_parm is True:
            hou_parm_template2 = hou.FolderParmTemplate("ik_cons_folder", "Ik Constraint",
                                                        folder_type=hou.folderType.MultiparmBlock,
                                                        default_value=1,
                                                        ends_tab_group=False)

            # Code for parameter template  PARENT BLENDS

            hou_parm_template3 = hou.StringParmTemplate("ik_constraint#", "Ik Constraint", 1, default_value=(["../character_placer/chain_1"]), naming_scheme=hou.parmNamingScheme.Base1,
                                                        string_type=hou.stringParmType.NodeReference, menu_items=([]),
                                                        menu_labels=([]), icon_names=([]), item_generator_script="",
                                                        item_generator_script_language=hou.scriptLanguage.Python,
                                                        menu_type=hou.menuType.Normal)
            hou_parm_template3.setConditional( hou.parmCondType.DisableWhen, "{ k_type == 0 }")
            hou_parm_template3.setTags({"opfilter": "!!OBJ!!", "oprelative": "."})

            #hou_parm_template3 = hou.StringParmTemplate("ik_constraint#", "Ik Constraint", 1,
            #											default_value=(["root_chain"]),
            #											naming_scheme=hou.parmNamingScheme.Base1,
            #											string_type=hou.stringParmType.NodeReferenceList,
            #											menu_items=([]),
            #											menu_labels=([]),
            #											icon_names=([]), item_generator_script="",
            #											item_generator_script_language=hou.scriptLanguage.Python,
            #											menu_type=hou.menuType.Normal)
            #hou_parm_template3.setConditional( hou.parmCondType.DisableWhen, "{ k_type == 0 }")
            #hou_parm_template3.setTags({"opfilter": "!!OBJ!!", "oprelative": "/"})
            #hou_parm_template3.setTags({"oprelative": "/"})

            hou_parm_template2.addParmTemplate(hou_parm_template3)
            hou_parm_template.addParmTemplate(hou_parm_template2)

        if ik_twist_parm is True:
            hou_parm_template2 = hou.StringParmTemplate("ik_twist_parent", "Ik Twist Parent", 1,
                                                        default_value=([""]),
                                                        #default_value=(["`chsop('hook')`"]),
                                                        naming_scheme = hou.parmNamingScheme.Base1,
                                                        string_type = hou.stringParmType.NodeReference,
                                                        menu_type = hou.menuType.Normal)
            hou_parm_template2.setConditional(hou.parmCondType.HideWhen, "{ k_type != 2 }")
            hou_parm_template2.setTags({"oprelative": "."})
            hou_parm_template.addParmTemplate(hou_parm_template2)

        # Code for parameter template POSITION  RIGHT LEFT CENTER
        #Code SETTING DOWN THE PARMS in THE UI
        template_group.insertBefore((0,), hou_parm_template)
        node_to_put_ui.setParmTemplateGroup(template_group)
        try:
            node_to_put_ui.parm("ik_constraint1").lock(1)
        except:
            pass

    def null(self):
        """ IN HOUDINI
        from hou_rig import guide_limb
        if len(hou.selectedNodes()) == 0 or hou.selectedNodes()[0].type().nameComponents()[2 ]== "subnet":
            hou.ui.displayMessage("Make sure you are selecting a valid Hook")
        else:
            limb = guide_limb.limb(hook = hou.selectedNodes()[0], limb_type = "single")
            limb.single()
        """
        self.g_node.setPosition([self.hook.parent().position()[0], self.hook.parent().position()[1]-1])
        self.g_node.setColor(hou.Color((0.55, 0.15, 0.15)))
        self.put_ui_in_node(self.g_node, default_type="null",
                            kinematic_parm=True,
                            kinematics_labels=["No Kinematics", "Multi Parents"],
                            stretchy_parm=False,
                            ik_slide_parm =False,
                            curve_toon_parm=False,
                            division_parm=False,
                            ik_goals_parm=True,
                            position_parm=True)
        self.g_node.parm("ik_constraint1").lock(0)
        self.g_node.parm("ik_constraint1").set("")

        self.hooking_a_node(self.g_node)

        # creating the nulls
        attachment = hou_rig.my_null.my_null(self.g_node, "chain_1")
        attachment.node("xform").parm("sx").set(0.5)

        attachment.parm("geoscale").set(.08)
        #self.hooking(do_line=False)

        fetch_node = self.create_fetch_node(self.g_node)
        list_for_guide = [fetch_node, attachment]

        self.parent_a_chain(list_for_guide)
        #curve = hou_rig.line_maker.create_line(self.limb_type+"_guide_curve", list_for_guide)
        #curve = self.make_guide_curve(self.limb_type+"_guide_curve", list_for_guide)
        #curve.setSelectableInViewport(0)
        #curve.parm("straight_curve").set(0)
        self.g_node.layoutChildren()

    def single(self):
        self.g_node.setPosition([self.hook.parent().position()[0], self.hook.parent().position()[1]-1])
        self.g_node.setColor(hou.Color((0.55, 0.15, 0.15)))
        self.put_ui_in_node(self.g_node, default_type="single")

        # creating the nulls
        attachment = hou_rig.my_null.my_null(self.g_node, "chain_1")
        attachment.node("xform").parm("sx").set(0.5)
        tip = hou_rig.my_null.my_null(self.g_node, "chain_2")
        tip.node("xform").parm("sx").set(0.5)

        self.list_for_guide = [attachment, tip]

        for i in self.list_for_guide:
            if i == attachment:
                i.parm("geoscale").set(.08)
            else:
                i.parm("geoscale").set(.1)
                #setting the shape of the null view
                #i.parm("controltype").set(1)
                # keeping position when parenting
                i.parm("keeppos").set(1)

        #position of the nulls in world space
        tip.parm("tx").set(attachment.parm("tx").eval())
        tip.parm("ty").set(attachment.parm("ty").eval() + 0.25)
        tip.parm("tz").set(attachment.parm("tz").eval())
        #todo fix the hooking and use the loose functions.
        self.hooking()
        self.hooking_a_node(self.g_node, "ik_twist_parent", lock=1, selectableInViewport=0)

    def geometry(self):
        """
        in houdini:
        from hou_rig import guide_limb
        geo = guide_limb.limb(limb_type="geometry")
        geo.geometry()
        """
        hou_rig.utils.ui_folder(self.g_node, in_this_folder=["Rig Parms"], insert_before_parm=(0,))
        rig_type = hou.StringParmTemplate("type", "type", 1, default_value=["geometry"])
        hou_rig.utils.parm_to_ui(self.g_node, rig_type, in_this_folder=["Rig Parms"])
        self.g_node.parm("type").lock(1)

        geometry_parm = hou.StringParmTemplate("import_geometry", "Geometry", 1,
                                                    default_value=(["geometry/the_autorig/will/use.bgeo"]),
                                                    naming_scheme=hou.parmNamingScheme.Base1,
                                                    string_type=hou.stringParmType.FileReference,
                                                    menu_items=([]), menu_labels=([]), icon_names=([]),
                                                    item_generator_script="",
                                                    item_generator_script_language=hou.scriptLanguage.Python,
                                                    menu_type=hou.menuType.StringReplace)
        geometry_parm.setHelp(
            'this can be fill later on inside the rig,'
            'this is the geometry that the rig will try to bring to the autorig.')
        hou_rig.utils.parm_to_ui(self.g_node, geometry_parm, in_this_folder=["Rig Parms"])

        self.g_node.setColor(hou.Color((0.8, 0.6, 0.25)))

    def flexor(self):
        self.g_node.setColor(hou.Color((0.1, 0.55, 0.5)))
        print "flexor"
        self.put_ui_in_node(self.g_node,
                    default_type="flexor",
                    kinematic_parm=False,
                    kinematics_labels = ["No Kinematics", "IK", "IK_With Effector"],
                    stretchy_parm=False,
                    ik_slide_parm =False,
                    curve_toon_parm=True,
                    division_parm=True,
                    ik_goal_label_warning=True,
                    ik_goals_parm=True,
                    position_parm=True)

        self.hooking_a_node(self.g_node)
        fetch_node = self.create_fetch_node(self.g_node)

        attachment = self.g_node.createNode("pathcv", "chain_1")
        attachment.parm("rx").set(90)
        attachment.parm("scale").set(0)

        tip = self.g_node.createNode("pathcv", "chain_2")
        tip.parm("ty").set(1)
        tip.parm("rx").set(90)
        tip.parm("scale").set(0)

        # attachment = hou_rig.my_null.my_null(self.g_node, "chain_1")
        # attachment.node("xform").parm("sx").set(0.5)
        # tip = hou_rig.my_null.my_null(self.g_node, "chain_2")
        # tip.node("xform").parm("sx").set(0.5)

        list_for_guide = [attachment, tip]
        for i in list_for_guide:
            i.setInput(0, fetch_node)
        #list_for_guide = [fetch_node, attachment, tip]
        #self.parent_a_chain(list_for_guide)

        curve = hou_rig.line_maker.create_line(self.limb_type+"_guide_curve", list_for_guide)
        #curve = self.make_guide_curve(self.limb_type+"_guide_curve", list_for_guide)
        curve.setSelectableInViewport(0)
        curve.parm("straight_curve").set(0)
        self.g_node.layoutChildren()

    def spine(self):
        self.g_node.setColor(hou.Color((0.1, 0.25, 0.5)))
        self.put_ui_in_node(self.g_node, default_type="spine")

        #creating the nulls
        attachment = hou_rig.my_null.my_null(self.g_node, "chain_1")
        attachment.node("xform").parm("sz").set(0.5)
        tip = hou_rig.my_null.my_null(self.g_node, "chain_2")
        tip.node("xform").parm("sz").set(0.5)

        self.list_for_guide = [attachment, tip]

        for i in self.list_for_guide:
            if i == attachment:
                i.parm("geoscale").set(.08)
            else:
                i.parm("geoscale").set(.1)
                #setting the shape of the null view
                #i.parm("controltype").set(1)
                # keeping position when parenting
                i.parm("keeppos").set(1)

        #position of the nulls in world space
        tip.parm("tx").set( attachment.parm("tx").eval() )
        tip.parm("ty").set( attachment.parm("ty").eval() + 0.25 )
        tip.parm("tz").set( attachment.parm("tz").eval() )
        self.hooking()

        if self.limb_type == "leg" or self.limb_type == "arm":
            print "creation"
            #creation of the nulls as point position for the bones
            attachment = hou_rig.my_null.my_null(self.g_node, "chain_1")
            bow = hou_rig.my_null.my_null(self.g_node, "chain_2")
            tip = hou_rig.my_null.my_null(self.g_node, "chain_3")

            list_for_guide = [attachment, bow, tip]

            #position of the nulls
            if self.limb_type == "leg":
                print "creation leg"
                self.put_ui_in_node(self.g_node, default_type="leg")
                self.g_node.setColor(hou.Color((.25,.25,.5)))
                bow.parm("tx").set( attachment.parm("tx").eval() )
                bow.parm("ty").set( attachment.parm("ty").eval() - 0.3 )
                bow.parm("tz").set( attachment.parm("tz").eval() + 0.15 )

                tip.parm("tx").set( bow.parm("tx").eval() )
                tip.parm("ty").set( bow.parm("ty").eval() - 0 )
                tip.parm("tz").set( bow.parm("tz").eval() - 0.2 )

            elif self.limb_type == "arm":
                print "creation arm"
                self.put_ui_in_node(self.g_node, default_type="arm")
                self.g_node.setColor(hou.Color((.5,.25,.25)))
                bow.parm("tx").set( attachment.parm("tx").eval() + 0.3)
                bow.parm("ty").set( attachment.parm("ty").eval()  )
                bow.parm("tz").set( attachment.parm("tz").eval() - 0.05)

                tip.parm("tx").set( bow.parm("tx").eval() + 0)
                tip.parm("ty").set( bow.parm("ty").eval()  )
                tip.parm("tz").set( bow.parm("tz").eval() + 0.1)

            for i in list_for_guide:
                if i == attachment:
                    i.parm("geoscale").set(.05)
                else:
                    #setting the size of the null view
                    i.parm("geoscale").set(.1)
                    #setting the shape of the null view
                    #i.parm("controltype").set(1)
                    #i.parm("keeppos").set(1)

        if self.limb_type == "foot":
            #the Foot method should check if the parent subnet and the hook to the multi IK list and set it up as
            # default


            self.g_node.setColor(hou.Color((0.5, 0.25, 0.85)))
            attachment = hou_rig.my_null.my_null(self.g_node, "attachment")
            bow = hou_rig.my_null.my_null(self.g_node, "bow")
            tip = hou_rig.my_null.my_null(self.g_node, "tip")
            toe = hou_rig.my_null.my_null(self.g_node, "toe")
            heel = hou_rig.my_null.my_null(self.g_node, "heel")

            list_for_guide = [attachment, bow, tip, toe, heel]

            for i in list_for_guide:
                if i == attachment:
                    i.parm("geoscale").set(0.05)
                else:
                #setting the size of the null view
                    i.parm("geoscale").set(0.1)
                #setting the shape of the null view
                #i.parm("controltype").set(1)
                #i.parm("keeppos").set(1)

            bow.parm("tx").set( attachment.parm("tx").eval() )
            bow.parm("ty").set( attachment.parm("ty").eval() - 0.1 )
            bow.parm("tz").set( attachment.parm("tz").eval() + 0.1 )

            tip.parm("tx").set( bow.parm("tx").eval() )
            tip.parm("ty").set( bow.parm("ty").eval() - 0.1 )
            tip.parm("tz").set( bow.parm("tz").eval() + 0.1 )

            toe.parm("tx").set( tip.parm("tx").eval() )
            toe.parm("ty").set( tip.parm("ty").eval() - 0.05)
            toe.parm("tz").set( tip.parm("tz").eval() + 0.05 )

            heel.parm("tx").set(tip.parm("tx").eval() )
            heel.parm("ty").set( 0 ) #tip.parm("ty").eval()  )
            heel.parm("tz").set( tip.parm("tz").eval() - 0.75 )

    def hooking(self, do_line=True):
        """
        will set a relative path from a limb to their hook
        and will create a fetch node
        and will connect all of them one after the other
        at the end will create a line that connect all of them to see in the view port
        do_line = will create a line that visualize the connection between limbs
        """
        self.hooking_a_node(self.g_node, "hook", lock=1, selectableInViewport=0)
        fetch_node = self.create_fetch_node(self.g_node)
        self.list_for_guide.insert(0, fetch_node)
        self.parent_a_chain(self.list_for_guide)
        if do_line is True:
        #Generate a curve line to see it on the view port
            self.make_guide_curve(self.limb_type+"_guide_curve", self.list_for_guide)

    def hooking_a_node(self, a_node, parm_name, lock=0, selectableInViewport=0):
        """
        find and set the hook parameter
        @param a_node: node to get the chain from:
        @param parm_name the string of the parameter name
        @return: hook path
        """
        a_node.parm(parm_name).set(self.g_node.relativePathTo(self.hook))
        a_node.parm("type").lock(lock)
        a_node.setSelectableInViewport(selectableInViewport)

    def create_fetch_node(self, a_node):
        """
        create a fetch node inside the subnet
        @param a_node: node where to put the fetch
        @return: the fetch node
        """
        fetch_node = a_node.createNode("fetch", "fetch_parent")
        fetch_node.setDisplayFlag(0)
        fetch_node.parm("fetchobjpath").set("`chsop('../hook')`")
        fetch_node.parm("useinputoffetched").set(1)
        fetch_node.parm("fetchsubnet").set(1)
        return fetch_node

    def parent_a_chain(self, list_of_nodes):
        for index, i in enumerate(list_of_nodes):
            i.setPosition([0, index*-1])
            try:
                i.setNextInput(i_temp)
            except:
                pass
            i_temp = i

    def make_guide_curve(self, name, list_of_nodes, where=None):
        curve = hou_rig.line_maker.create_line(name, list_of_nodes, where)
        curve.setSelectableInViewport(0)
        return curve