#class utilities(object):
import hou
#making a change for a commit


def ui_folder(node_to_put_the_folder, in_this_folder=[None], insert_before_parm=None, insert_after_parm=None):
    """
    creates a folder in the UI of the given node
    node_to_put_the_folder = node where we are going to create the folder
    in_this_folder = []  is expecting a tuple of strings, each string represent a folder, that its inside a
    folder example ['bla', 'ble', 'bli'] where folder bli, is inside ble, thats inside bla.
    to specify a folder name should be the last string of the tupple, example
    if the folder where you want to put the folder is call "test"   the tupple should be ["test", "name of the folder"]
    """
    tg = node_to_put_the_folder.parmTemplateGroup()
    folder_found = tg.findFolder(in_this_folder)

    if folder_found is None:
        for index, item in enumerate(in_this_folder):
            if len(in_this_folder) == 1:
                prog_list = in_this_folder[0]
            else:
                prog_list = in_this_folder[0:index + 1]
            folder_found = tg.findFolder(prog_list)

            if folder_found is not None:
                last_folder_found = folder_found
            elif folder_found is None:
                folder_parm_template = hou.FolderParmTemplate(item, item)
                try:
                    tg.appendToFolder(last_folder_found, folder_parm_template)
                except:
                    pass
                    #	tg.append(folder_parm_template)
                last_folder_found = folder_parm_template

    if insert_before_parm is not None:
        tg.insertBefore(insert_before_parm, last_folder_found)

    if insert_after_parm is not None:
        tg.insertAfter(insert_after_parm, last_folder_found)

    node_to_put_the_folder.setParmTemplateGroup(tg)


def parm_to_ui(node_to_put_the_parm, parm_to_add, in_this_folder=None, insert_before_parm=None, insert_after_parm=None,
               join_with_next_parm=False):
    """
    put a parm in the ui
    node = is the node where the parm will be added
    parm to add is the hou.###.ParmTemplate that will be added
    in_this_folder = tuple of the folders paths example. ['bla','ble'] where ble is inside bla.
    insertBefore_parm = will put the parm_to_add before this parm.
    insertAfter_parm = will put the parm_to_add after this parm.
    BEWARE you can only have,  in the args folder, or 	insertBefore_parm, or insertAfter_parm
    """
    #todo do a dummy invisible parameter that will work as buffer for set Next parm_to_add should be a list of parm, so the join with next works
    if join_with_next_parm is True:
        parm_to_add.setJoinWithNext(1)

    tg = node_to_put_the_parm.parmTemplateGroup()
    if in_this_folder is not None:
        try:
            tg_folder = tg.findFolder(in_this_folder)
            tg.appendToFolder(tg_folder, parm_to_add)
        except:
            print "folder doesnt exist you should run a function to create the folder if doesnt exist."
    elif insert_before_parm is not None:
        tg.insertBefore(insert_before_parm, parm_to_add)
    elif insert_after_parm is not None:
        tg.insertAfter(insert_after_parm, parm_to_add)
    elif in_this_folder is None or insert_before_parm is None or insert_after_parm is None:
        tg.append(parm_to_add)
    try:
        node_to_put_the_parm.setParmTemplateGroup(tg)
    except:
        print "the parm name allready exist, try using another name"
        raise StandardError()


def promote_parm_to_ui(parm_to_add, node_to_put_the_parm, in_this_folder=None, insert_before_parm=None,
                       insert_after_parm=None, parm_name=None, parm_label=None, ch_link=True, join_with_next_parm=False,
                       minimum=None, maximum=None):
    """
    parm_to_add = is the parameter from the ui that we want to promote
    node_to_put_the_parm = the node where we want to send the parameter
    in_this_folder = will put it in that folder tuple of folders ["bla", "ble"]
    insertBefore_parm =  will put the created parameter before this parm
    insertAfter_parm =  will put the created parameter after this parm
        in case the parms all ready exist or the user want another name
    parm_name = the internal name fo the parm
    parm_label = how the name is display in the ui
    ch_link = channel link,  will create the link reference between promoted parm and original parm.
    join_with_next_parm if put the parm in the same line or not.
    """


    if type(parm_to_add) == hou.Parm:
        print "its a parm"
    elif type(parm_to_add) == hou.ParmTuple:
        print "its a tuple"

    parm_to_add_template = parm_to_add.parmTemplate()
    #print parm_to_add_template


    try:
        parm_to_add_template.setDefaultValue(parm_to_add.eval())
    except:
        parm_to_add_template.setDefaultValue([parm_to_add.eval()])

    print parm_to_add_template
    print parm_to_add.eval()
    print tuple(parm_to_add.eval())
    parm_to_add_template.setDefaultValue(tuple(parm_to_add.eval() ) )























    if join_with_next_parm is True:
        parm_to_add_template.setJoinWithNext(True)

    if parm_name is not None:
        parm_to_add_template.setName(parm_name)
    if parm_label is not None:
        parm_to_add_template.setLabel(parm_label)
    if minimum is not None:
        parm_to_add_template.setMinValue(minimum)
    if maximum is not None:
        parm_to_add_template.setMaxValue(maximum)

    if in_this_folder is not None:
        ui_folder(node_to_put_the_parm, in_this_folder)

    parm_to_ui(node_to_put_the_parm, parm_to_add_template, in_this_folder=in_this_folder,
               insert_before_parm=insert_before_parm, insert_after_parm=insert_after_parm)




    parm_to_add_length = parm_to_add_template.numComponents()
    if ch_link is True:
        if parm_to_add_length == 1:
            parm_to_add.set(node_to_put_the_parm.parm(parm_to_add_template.name()))

        elif parm_to_add_length > 1:
            if str(parm_to_add.parmTemplate().namingScheme()) == "parmNamingScheme.XYZW":
                cord = ["x", "y", "z", "w"]
                for i in range(0, parm_to_add_length):
                    parm_to_add[i].set(node_to_put_the_parm.parm(parm_to_add_template.name() + cord[i]))

            else:
                #todo fix to make this work for tuples or in the script make a for each parameter
                for i in range(0, parm_to_add_length):
                    parm_name = str( parm_to_add_template.name()+str(i+1) )
                    parm_to_add.set(node_to_put_the_parm.parm(parm_name) )








def hide_folder_or_parm_from_ui(node_to_hide_the_parm, hide_this=[]):
    """
    node_to_hide_the_parm = is the node that we are going to hide the parameter
    hide_this=[]  = is the folder or parm that we want to hide form the UI use brackets for folders, strings for parms.
    """
    tg = node_to_hide_the_parm.parmTemplateGroup()

    parm_template = tg.find(hide_this)
    parm_template.hide(on)
    tg.replace(hide_this, parm_template)


    # if "list" in str(type(hide_this)) or "tuple" in str(type(hide_this)):
    #     tg.hideFolder(hide_this, True)
    # else:
    #     tg.hide(hide_this, True)
    node_to_hide_the_parm.setParmTemplateGroup(tg)


def list_of_parms_to_promote_to_ui(list_of_nodes, list_of_desire_parms, node_to_parm=None, into_this_folder=[],
                                   separator_line=True):
#todo put a label in front of the separator_line with the name of the node
    for i in list_of_nodes:
        for j in list_of_desire_parms:
            if j[1] == "parm":
                parm = i.parm(j[0])
            elif j[1] == "tuple":
                parm = i.parmTuple(j[0])
            jwnp = False
            for itn in j:
                if itn == "jwnp":
                    # print itn
                    jwnp = True
                if "label" in str(itn):
                    label = itn.split("=")[1]
                else:
                    label = False

            if label is False:
                promote_parm_to_ui(parm,
                                   node_to_parm,
                                   in_this_folder=into_this_folder,
                                   parm_name=i.parent().name() + "_" + i.name() + "_" + j[0],
                                   ch_link=True,
                                   join_with_next_parm=jwnp)

            else:
                promote_parm_to_ui(parm,
                                   node_to_parm,
                                   in_this_folder=into_this_folder,
                                   parm_name=i.parent().name() + "_" + i.name() + "_" + j[0],
                                   parm_label=label,
                                   ch_link=True,
                                   join_with_next_parm=jwnp)

        if separator_line is True:
            loop = 0
            while True:
                try:
                    separator_parm = hou.SeparatorParmTemplate(
                        i.parent().name() + "_" + i.name() + "separator" + str(loop))
                    parm_to_ui(node_to_parm, separator_parm, in_this_folder=into_this_folder)
                    break
                except:
                    loop += 1