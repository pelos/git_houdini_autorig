import hou
import utils

"""
##in houdini
from hou_rig import line_maker

name = "guide_curve"
centers = hou.selectedNodes()
if len(centers) <=0:
    print "Please select 3 or more nodes"
else:
    parent = centers[0]
    line_maker.create_line(parent, name, centers)
"""


def create_line(name, centers, where=None, name_of_node_to_merge="point1", imp_normals=False):
    """
    creates a line/curve from the incoming geometry, example select 2 nulls and will make a line from them.
    @param name: name of the created curve
    @param centers: a list of nodes
    @param where: where is going to place the curve
    @param name_of_node_to_merge: what the node inside the centers that will grab
    @param imp_normals: true or false if add extra stuff to the curve, (use for toon curve bones)
    @return: the created curve
    """
    level = centers[0].parent()
    if where is not None:
        level = centers[0].parent()

    curve = level.createNode("geo", name)
    curve.node("file1").destroy()
    curve.moveToGoodPosition()
    curve.setColor(hou.Color((.6, .6, 1)))

    merge_node = curve.createNode("merge")

    add_all = curve.createNode("add","add_generate_line")
    add_all.parm("stdswitcher1").set(1)
    add_all.parm("switcher1").set(1)
    add_all.setInput(0, merge_node, 0)

    convert_node = curve.createNode("convert", "convert_to_curve")
    convert_node.parm("totype").set(4)
    convert_node.setInput(0, add_all, 0)

    convert_to_poly = curve.createNode("convert")
    convert_to_poly.setInput(0, convert_node, 0)

    switch_node = curve.createNode("switch")

    switch_node.setNextInput(convert_to_poly)
    switch_node.setNextInput(add_all)

    tg = curve.parmTemplateGroup()
    poly_toggle_parm = hou.ToggleParmTemplate("polywire", "polywire", 0)
    sc_toggle_parm = hou.ToggleParmTemplate("straight_curve", "Straight Curve", 0)
    sc_toggle_parm.setDefaultValue(True)
    wire_rad_parm = hou.FloatParmTemplate("wire_rad", "Wire Rad", 1)

    tg.insertBefore((0,), poly_toggle_parm)
    tg.insertBefore((0,), sc_toggle_parm)
    tg.insertBefore((0,), wire_rad_parm)

    curve.setParmTemplateGroup(tg)

    switch_node.parm("input").set(curve.parm("straight_curve"))

    wire_node = curve.createNode("polywire", "wire_view")
    curve.parm("wire_rad").set(0.05)
    wire_node.parm("radius").set(curve.parm("wire_rad"))
    wire_node.parm("div").set(6)

    wire_node.setInput(0,switch_node,0)

    switch_poly = curve.createNode("switch", "switch_poly")
    switch_poly.setNextInput(switch_node)
    switch_poly.setNextInput(wire_node)
    switch_poly.parm("input").set(curve.parm("polywire"))

    null_out = curve.createNode("null", "OUT")
    null_out.setInput(0, switch_poly)
    null_out.setDisplayFlag(1)
    null_out.setRenderFlag(1)

    for i in centers:
        obj_merge = curve.createNode("object_merge", "object_merge_" + i.name())
        obj_merge.parm("xformtype").set(1)
        rel = obj_merge.relativePathTo(i)

        obj_merge.parm("objpath1").set(rel+"/"+name_of_node_to_merge)

        merge_node.setNextInput(obj_merge)

    if imp_normals is True:
        curve_import_normals(curve)

    curve.layoutChildren()
    return curve


def curve_import_normals(curve):
    """
    for a given curve will add extra nodes to use stretch and squash an attribute
    @param curve: the curve that will add the nodes
    @return:
    """
    #if doesnt have OUT null, then use the render flag node.
    try:
        null_out = curve.node("OUT")
    except:
        for i in curve.children():
            if i.isRenderFlagSet() is True:
                null_out = i

    time_shift = curve.createNode("timeshift", "timeshift_rest")
    time_shift.parm("frame").setExpression("$FSTART")
    time_shift.setInput(0, null_out)

    vopsop = curve.createNode("vopsop", "vopsop_streatch_and_squash")
    vopsop.setInput(0, null_out)
    vopsop.setInput(1, time_shift)
    globals = vopsop.node("global1")

    itf = vopsop.createNode("inttofloat")
    itf.setInput(0, globals, 8)

    div = vopsop.createNode("divide")
    div.setInput(0, itf, 0)
    div.setInput(1, globals, 11)

    #-----------------------------
    ramp_stre = vopsop.createNode("rampparm", "ramp_stretch")
    ramp_stre.parm("parmname").set("stretch_ramp")
    ramp_stre.parm("parmlabel").set("Stretch Ramp")
    ramp_stre.parm("rampshowcontrolsdefault").set(0)
    ramp_stre.parm("ramptype").set(1)
    ramp_stre.parm("rampbasisdefault").set("catmull-rom")
    basis = hou.rampBasis.CatmullRom
    ramp_default = hou.Ramp((basis, basis, basis), (0, 0.5, 1), (0, 1, 0))
    vopsop.parm("stretch_ramp").set(ramp_default)

    ramp_stre.setInput(0, div, 0)

    stre_mult_parm = vopsop.createNode("parameter")
    stre_mult_parm.parm("parmname").set("stretch_ramp_mult")
    stre_mult_parm.parm("parmlabel").set("Stretch Ramp Mult")
    stre_mult_parm.parm("floatdef").set(1)
    stre_mult_parm.parmTuple("rangeflt").set([0, 10])

    stre_mult_parm.parm("joinnext").set(1)

    stre_mult = vopsop.createNode("multiply")
    stre_mult.setInput(0, ramp_stre)
    stre_mult.setInput(1, stre_mult_parm)

    stre_clamp_parm = vopsop.createNode("parameter")
    stre_clamp_parm.parm("parmname").set("stretch_cap")
    stre_clamp_parm.parm("parmlabel").set("Stretch Cap")
    stre_clamp_parm.parm("floatdef").set(20)
    stre_clamp_parm.parmTuple("rangeflt").set([0, 20])

    stre_clamp = vopsop.createNode("clamp", "clamp_cap_ramp")
    stre_clamp.setInput(0, stre_mult, 0)
    stre_clamp.setInput(2, stre_clamp_parm, 0)
    #-------------------------------------
    ramp_squa = vopsop.createNode("rampparm", "ramp_squash")
    ramp_squa.parm("parmname").set("squash_ramp")
    ramp_squa.parm("parmlabel").set("Squash Ramp")
    ramp_squa.parm("rampshowcontrolsdefault").set(0)
    ramp_squa.parm("ramptype").set(1)
    ramp_squa.parm("ramptype").set(1)
    ramp_squa.parm("rampbasisdefault").set("catmull-rom")
    vopsop.parm("squash_ramp").set(ramp_default)
    ramp_squa.setInput(0, div, 0)

    squa_mult_parm = vopsop.createNode("parameter")
    squa_mult_parm.parm("parmname").set("squash_ramp_mult")
    squa_mult_parm.parm("parmlabel").set("Squash Ramp Mult")
    squa_mult_parm.parm("floatdef").set(1)
    squa_mult_parm.parm("floatdef").set(1)
    squa_mult_parm.parmTuple("rangeflt").set([0, 10])
    squa_mult_parm.parm("joinnext").set(1)

    squa_mult = vopsop.createNode("multiply")
    squa_mult.setInput(0, ramp_squa)
    squa_mult.setInput(1, squa_mult_parm)

    squa_clamp_parm = vopsop.createNode("parameter")
    squa_clamp_parm.parm("parmname").set("squash_cap")
    squa_clamp_parm.parm("parmlabel").set("Squash Cap")
    squa_clamp_parm.parm("floatdef").set(0.01)
    squa_clamp_parm.parmTuple("rangeflt").set([0, 20])

    squa_clamp = vopsop.createNode("clamp", "clamp_cap_ramp")
    squa_clamp.setInput(0, squa_mult, 0)
    squa_clamp.setInput(2, squa_clamp_parm, 0)
    #---------------------------------------
    ori_len_parm = vopsop.createNode("parameter")
    ori_len_parm.parm("parmname").set("original_curve_len")
    ori_len_parm.parm("parmlabel").set("Original Curve Length")
    ori_len_parm.parm("floatdef").set(0)
    ori_len_parm.parm("joinnext").set(1)
    vopsop.parm("original_curve_len").setExpression('arclen(opinputpath(".",1),0,0,1)')

    current_len_parm = vopsop.createNode("parameter")
    current_len_parm.parm("parmname").set("current_curve_len")
    current_len_parm.parm("parmlabel").set("Current Curve Length")
    current_len_parm.parm("floatdef").set(0)
    vopsop.parm("current_curve_len").setExpression('arclen(opinputpath(".",0),0,0,1)')

    divi_len = vopsop.createNode("divide")
    divi_len.setInput(0, ori_len_parm, 0)
    divi_len.setInput(1, current_len_parm, 0)

    cons = vopsop.createNode("addconst")
    cons.parm("addconst").set(-1)
    cons.setInput(0, divi_len, 0)

    compare = vopsop.createNode("compare")
    compare.setInput(0, ori_len_parm)
    compare.setInput(1, current_len_parm)
    compare.parm("cmp").set("gt")

    two_ways = vopsop.createNode("twoway")
    two_ways.parm("condtype").set(0)
    two_ways.setInput(0, compare, 0)
    two_ways.setInput(1, squa_clamp, 0)
    two_ways.setInput(2, stre_clamp, 0)

    mult_cons_two = vopsop.createNode("multiply")
    mult_cons_two.setInput(0, cons, 0)
    mult_cons_two.setInput(1, two_ways, 0)

    cons_one = vopsop.createNode("addconst")
    cons_one.parm("addconst").set(1)
    cons_one.setInput(0, mult_cons_two, 0)

    bind_export = vopsop.createNode("bind")
    bind_export.parm("parmname").set("bscale")
    bind_export.parm("useasparmdefiner").set(1)
    bind_export.parm("exportparm").set(2)
    bind_export.setInput(0, cons_one)
    #-----------------------------------------

    pw = curve.createNode("pointwrangle", "pointwrangle_make_local_variable")
    pw.parm("snippet").set("f@bscale = @bscale; addvariablename('bscale', 'BSCALE');")
    pw.setInput(0, vopsop)

    resample = curve.createNode("resample")
    resample.parm("last").set(1)
    resample.parm("length").set(0)
    resample.parm("dosegs").set(1)
    resample.parm("segs").set(15)
    utils.promote_parm_to_ui(resample.parm("segs"), curve, insert_after_parm="wire_rad")
    resample.setInput(0, pw)

    null_out_seg = curve.createNode("null", "Out_Segs")
    null_out_seg.setInput(0, resample)